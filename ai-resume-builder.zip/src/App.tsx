import { useState, useEffect } from "react";
import { ResumeData, ResumeTemplate } from "./types";
import { INITIAL_RESUME_DATA } from "./utils";
import ResumeForm from "./components/ResumeForm";
import ResumePreview from "./components/ResumePreview";
import { 
  Sparkles, Download, Printer, Sun, Moon, RefreshCcw, 
  FileText, Layout, CheckCircle, Eye, Edit3
} from "lucide-react";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  // Load initial resume data from localStorage with a fallback
  const [resumeData, setResumeData] = useState<ResumeData>(() => {
    const saved = localStorage.getItem("resume_data");
    if (saved) {
      try {
         return JSON.parse(saved);
      } catch {
         return INITIAL_RESUME_DATA;
      }
    }
    return INITIAL_RESUME_DATA;
  });

  // Load template selection from localStorage with fallback
  const [template, setTemplate] = useState<ResumeTemplate>(() => {
    const saved = localStorage.getItem("resume_template");
    if (saved && Object.values(ResumeTemplate).includes(saved as ResumeTemplate)) {
      return saved as ResumeTemplate;
    }
    return ResumeTemplate.PROFESSIONAL;
  });

  // Load dark mode setting from localStorage
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem("resume_dark_mode");
    return saved === "true";
  });

  // PDF generation and mobile segment toggle states
  const [pdfLoading, setPdfLoading] = useState<boolean>(false);
  const [mobileView, setMobileView] = useState<"edit" | "preview">("edit");
  const [saveStatus, setSaveStatus] = useState<string>("Synced");

  // Save changes to localStorage automatically
  useEffect(() => {
    localStorage.setItem("resume_data", JSON.stringify(resumeData));
    setSaveStatus("Saving...");
    const timer = setTimeout(() => setSaveStatus("Synced"), 700);
    return () => clearTimeout(timer);
  }, [resumeData]);

  useEffect(() => {
    localStorage.setItem("resume_template", template);
  }, [template]);

  useEffect(() => {
    localStorage.setItem("resume_dark_mode", String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  // Sanitizer to temporarily remove unsupported color formulas (oklch, oklab, lab, lch) from sheets during html2canvas rendering
  const sanitizeStylesheets = () => {
    const backups: { element: HTMLStyleElement; originalText: string }[] = [];
    const linkBackups: { element: HTMLLinkElement; originalDisabled: boolean }[] = [];

    // 1. Sanitize all inline <style> elements
    const styles = Array.from(document.querySelectorAll("style"));
    styles.forEach((style) => {
      try {
        const text = style.textContent || "";
        if (
          text.includes("oklch") || 
          text.includes("oklab") || 
          text.includes("lab(") || 
          text.includes("lch(")
        ) {
          backups.push({ element: style, originalText: text });
          const cleanedText = text
            .replace(/oklch\([^)]+\)/gi, "#1e3a8a")
            .replace(/oklab\([^)]+\)/gi, "#1e3a8a")
            .replace(/lab\([^)]+\)/gi, "#1e3a8a")
            .replace(/lch\([^)]+\)/gi, "#1e3a8a");
          style.textContent = cleanedText;
        }
      } catch (err) {
        console.warn("Could not patch stylesheet:", err);
      }
    });

    // 2. Temporarily disable Tailwind stylesheet/links that could trigger parsing failures
    const links = Array.from(document.querySelectorAll("link[rel='stylesheet']"));
    links.forEach((link) => {
      try {
        const href = link.getAttribute("href") || "";
        if (
          href.includes("tailwind") || 
          href.includes("main") || 
          href.includes("index") || 
          !href.startsWith("http")
        ) {
          linkBackups.push({ element: link as HTMLLinkElement, originalDisabled: (link as any).disabled });
          (link as any).disabled = true;
        }
      } catch (err) {
        console.warn("Could not handle link element:", err);
      }
    });

    return () => {
      // Restore styles content
      backups.forEach(({ element, originalText }) => {
        try {
          element.textContent = originalText;
        } catch (err) {
          console.error("Could not restore stylesheet text content:", err);
        }
      });
      // Restore disabled links
      linkBackups.forEach(({ element, originalDisabled }) => {
        try {
          element.disabled = originalDisabled;
        } catch (err) {
          console.error("Could not restore link stylesheet state:", err);
        }
      });
    };
  };

  // Handle PDF Export
  const handleDownloadPDF = async () => {
    const element = document.getElementById("resume-print-preview");
    if (!element) {
      alert("Resume preview element is missing.");
      return;
    }
    setPdfLoading(true);

    // Temp element style overrides if parent container is currently hidden (e.g. mobile "Edit" view)
    const previewContainer = document.getElementById("resume-print-preview-container");
    let originalStyleAttr: string | null = null;
    let didForceVisible = false;

    if (previewContainer) {
      const isHidden = window.getComputedStyle(previewContainer).display === "none";
      if (isHidden) {
        originalStyleAttr = previewContainer.getAttribute("style");
        previewContainer.style.setProperty("display", "block", "important");
        previewContainer.style.setProperty("position", "absolute", "important");
        previewContainer.style.setProperty("top", "-9999px", "important");
        previewContainer.style.setProperty("left", "-9999px", "important");
        previewContainer.style.setProperty("width", "800px", "important");
        previewContainer.style.setProperty("visibility", "visible", "important");
        didForceVisible = true;
      }
    }

    // Apply the stylesheet sanitization
    const restoreStyles = sanitizeStylesheets();

    try {
      const canvas = await html2canvas(element, {
        scale: 2, // clear rendering output
        useCORS: true,
        backgroundColor: "#ffffff"
      });

      const imgData = canvas.toDataURL("image/jpeg", 0.95);
      
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "pt",
        format: "a4"
      });

      const pdfWidth = Number(pdf.internal.pageSize.getWidth());
      const pdfHeight = Number(pdf.internal.pageSize.getHeight());
      
      const canvasWidth = Number(canvas.width);
      const canvasHeight = Number(canvas.height);

      if (isNaN(canvasWidth) || canvasWidth <= 0 || isNaN(canvasHeight) || canvasHeight <= 0) {
        throw new Error(`Invalid canvas dimensions calculated: ${canvasWidth}x${canvasHeight}`);
      }

      const imgWidth = pdfWidth;
      const imgHeight = (canvasHeight * imgWidth) / canvasWidth;
      
      if (isNaN(imgWidth) || !isFinite(imgWidth) || imgWidth <= 0 || isNaN(imgHeight) || !isFinite(imgHeight) || imgHeight <= 0) {
        throw new Error(`Invalid image dimensions calculated: width=${imgWidth}, height=${imgHeight}`);
      }

      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, "JPEG", 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;

      // Handle multi-page resumes cleanly
      let safetyCounter = 0;
      while (heightLeft >= 0.5 && safetyCounter < 10) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, "JPEG", 0, position, imgWidth, imgHeight);
        heightLeft -= pdfHeight;
        safetyCounter++;
      }

      const safeName = (resumeData.personalInfo.fullName || "Resume").trim().replace(/\s+/g, "_");
      pdf.save(`${safeName}_Resume.pdf`);
    } catch (e: any) {
      console.error("PDF generation failed:", e);
      alert("Error generating PDF document: " + (e.message || e));
    } finally {
      // Restore styles and visibility
      restoreStyles();
      if (previewContainer && didForceVisible) {
        if (originalStyleAttr !== null) {
          previewContainer.setAttribute("style", originalStyleAttr);
        } else {
          previewContainer.removeAttribute("style");
        }
      }
      setPdfLoading(false);
    }
  };

  // Handle Print Action
  const handlePrint = () => {
    window.focus();
    window.print();
  };

  // Reset to default sample draft
  const handleReset = () => {
    if (window.confirm("Are you sure you want to reset the form content to template defaults? All unsaved current progress will be replaced.")) {
      setResumeData(INITIAL_RESUME_DATA);
      setTemplate(ResumeTemplate.PROFESSIONAL);
    }
  };

  return (
    <div className="min-h-screen font-sans bg-gray-50/50 dark:bg-gray-950 text-gray-900 dark:text-gray-100 transition-colors duration-300 pb-16">
      
      {/* HEADER CONTROLS (Hide in prints) */}
      <header id="header-controls" className="sticky top-0 z-35 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 lg:px-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Logo and Saving Status */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-gradient-to-tr from-indigo-500 to-blue-600 text-white shadow-md animate-pulse">
                <Sparkles size={18} />
              </div>
              <div>
                <h1 className="text-sm font-bold tracking-tight font-display bg-gradient-to-r from-gray-900 to-gray-700 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
                  ResumeCraft AI
                </h1>
                <div className="flex items-center gap-1 text-[10px] text-gray-500 dark:text-gray-400">
                  <CheckCircle size={10} className="text-indigo-500" />
                  <span>{saveStatus} in local storage</span>
                </div>
              </div>
            </div>

            {/* Quick Dark Mode & Reset buttons for tiny screens */}
            <div className="flex items-center gap-1 md:hidden">
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-1.5 rounded-lg border border-gray-150 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800"
                title="Toggle Mode"
              >
                {darkMode ? <Sun size={15} /> : <Moon size={15} />}
              </button>
              <button
                onClick={handleReset}
                className="p-1.5 rounded-lg border border-gray-150 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-500 dark:text-gray-400 hover:text-red-500 hover:bg-gray-50 dark:hover:bg-gray-800"
                title="Reset Defaults"
              >
                <RefreshCcw size={15} />
              </button>
            </div>
          </div>

          {/* Core Builder Settings Toolbar */}
          <div className="flex flex-wrap items-center gap-2.5">
            
            {/* Template Selector dropdown or buttons */}
            <div className="flex items-center gap-1 p-1 bg-gray-100 dark:bg-gray-800 rounded-xl border border-gray-150 dark:border-gray-700">
              {(Object.keys(ResumeTemplate) as Array<keyof typeof ResumeTemplate>).map((key) => {
                const val = ResumeTemplate[key];
                const active = template === val;
                return (
                  <button
                    key={val}
                    onClick={() => setTemplate(val)}
                    className={`px-3 py-1 text-xs font-semibold rounded-lg capitalize transition-all cursor-pointer ${
                      active 
                        ? "bg-white dark:bg-gray-900 text-indigo-600 dark:text-indigo-400 shadow-sm"
                        : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                    }`}
                  >
                    {val}
                  </button>
                );
              })}
            </div>

            {/* Extra desktop quick items */}
            <div className="hidden md:flex items-center gap-1.5">
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-2 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-800 transition-all cursor-pointer"
                title={darkMode ? "Use Light Mode" : "Use Dark Mode"}
              >
                {darkMode ? <Sun size={15} /> : <Moon size={15} />}
              </button>

              <button
                onClick={handleReset}
                className="p-2 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:bg-gray-900 dark:hover:bg-red-950/20 transition-all cursor-pointer"
                title="Reset to Template Default Fields"
              >
                <RefreshCcw size={15} />
              </button>
            </div>

            {/* Print and PDF Triggers */}
            <div className="flex items-center gap-1.5 ml-auto md:ml-0">
              <button
                onClick={handlePrint}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300 shadow-sm cursor-pointer transition-all"
              >
                <Printer size={14} />
                <span>Print Resume</span>
              </button>

              <button
                onClick={handleDownloadPDF}
                disabled={pdfLoading}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl text-white bg-indigo-600 hover:bg-indigo-700 hover:shadow-md disabled:bg-indigo-400 shadow-sm transition-all cursor-pointer"
              >
                {pdfLoading ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Compiling PDF...</span>
                  </>
                ) : (
                  <>
                    <Download size={14} />
                    <span>Download PDF</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>
      </header>

      {/* MOBILE SEGMENT SELECTOR TAB (Hide in prints, show on mobile screens only) */}
      <div className="no-print lg:hidden max-w-7xl mx-auto px-4 pt-4">
        <div className="grid grid-cols-2 gap-1 p-1 bg-gray-150 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
          <button
            onClick={() => setMobileView("edit")}
            className={`flex items-center justify-center gap-1.5 py-2.5 text-xs font-semibold rounded-lg transition-all ${
              mobileView === "edit"
                ? "bg-white dark:bg-gray-850 text-indigo-600 dark:text-indigo-400 shadow"
                : "text-gray-500 hover:text-gray-900 dark:text-gray-400"
            }`}
          >
            <Edit3 size={14} />
            <span>Edit Information Form</span>
          </button>
          <button
            onClick={() => setMobileView("preview")}
            className={`flex items-center justify-center gap-1.5 py-2.5 text-xs font-semibold rounded-lg transition-all ${
              mobileView === "preview"
                ? "bg-white dark:bg-gray-850 text-indigo-600 dark:text-indigo-400 shadow"
                : "text-gray-500 hover:text-gray-900 dark:text-gray-400"
            }`}
          >
            <Eye size={14} />
            <span>Interactive Live Preview</span>
          </button>
        </div>
      </div>

      {/* DASHBOARD LAYOUT GRID */}
      <main className="max-w-7xl mx-auto px-4 pt-4 sm:px-6 lg:px-8 mt-2">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* LEFT PANEL: RESUME FORM EDITOR */}
          <div 
            id="editor-container" 
            className={`lg:col-span-5 space-y-4 no-print ${
              mobileView === "edit" ? "block" : "hidden lg:block"
            }`}
          >
            <div className="flex items-center gap-2 mb-2 lg:mb-4 px-1">
              <FileText size={18} className="text-indigo-500" />
              <h2 className="text-sm font-bold tracking-tight text-gray-800 dark:text-gray-200 uppercase">
                Candidate Information Dossier
              </h2>
            </div>
            
            <ResumeForm 
              data={resumeData} 
              onChange={setResumeData} 
            />
          </div>

          {/* RIGHT PANEL: INTERACTIVE LIVE PREVIEW CANVAS */}
          <div 
            id="resume-print-preview-container" 
            className={`lg:col-span-7 flex flex-col items-center ${
              mobileView === "preview" ? "block" : "hidden lg:block"
            }`}
          >
            {/* Desktop Preview Header Indicator */}
            <div className="no-print w-full max-w-[800px] flex items-center justify-between mb-4 px-1">
              <div className="flex items-center gap-2">
                <Layout size={18} className="text-indigo-500" />
                <h2 className="text-sm font-bold tracking-tight text-gray-800 dark:text-gray-200 uppercase">
                  ATS Application Preview – <span className="capitalize">{template} Blueprint</span>
                </h2>
              </div>
              <div className="text-[11px] text-gray-400 bg-gray-100 dark:bg-gray-900 px-2.5 py-1 rounded-full font-semibold border border-gray-150 dark:border-gray-800">
                A4 Scale Render Output
              </div>
            </div>

            {/* The Resume Preview Canvas Frame */}
            <div className="w-full flex justify-center">
              <ResumePreview 
                data={resumeData} 
                template={template} 
              />
            </div>
          </div>

        </div>
      </main>

    </div>
  );
}
