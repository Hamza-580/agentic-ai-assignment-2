import { ResumeData } from "./types";

export function compressImage(file: File, maxWidth: number = 200, maxHeight: number = 200): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Calculate aspect ratios
        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(img.src);

        // Fill with white background in case of transparent PNG
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);

        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85); // 85% quality JPEG
        resolve(dataUrl);
      };
      img.onerror = () => reject(new Error('Image load error'));
    };
    reader.onerror = () => reject(new Error('File reading error'));
  });
}

export const INITIAL_RESUME_DATA: ResumeData = {
  personalInfo: {
    fullName: "Alex Rivera",
    jobTitle: "Senior Full-Stack Engineer",
    email: "alex.rivera@example.com",
    phone: "+1 (555) 019-2834",
    location: "San Francisco, CA",
    website: "https://alexrivera.dev",
    linkedin: "https://linkedin.com/in/alexrivera-dev",
    summary: "Solution-oriented and high-performing Full-Stack Engineer with 6+ years of experience designing high-scalability web applications. Proven track record of reducing API latency by 45% and designing beautiful, accessible user-interfaces using modern architectural patterns.",
    profilePic: "" // Empty by default
  },
  education: [
    {
      id: "edu1",
      school: "University of California, Berkeley",
      degree: "Bachelor of Science",
      fieldOfStudy: "Computer Science",
      startDate: "2016-09",
      endDate: "2020-05",
      current: false,
      description: "Graduated with Honors. Specialized in Software Architecture and UI/UX design components. Teaching Assistant for Web Applications."
    }
  ],
  experience: [
    {
      id: "exp1",
      company: "InnovateTech Solutions",
      role: "Lead Full-Stack Web Developer",
      location: "San Francisco, CA",
      startDate: "2022-06",
      endDate: "",
      current: true,
      description: "• Developed robust client-side routing and optimized Local Storage session states for 50k active daily users.\n• Automated continuous integration builds and migrated server processes to Express, gaining 30% pipeline efficiency.\n• Orchestrated accessible layout designs matching highest-quality guidelines with rich tailwind styles."
    },
    {
      id: "exp2",
      company: "Apex Development Corp",
      role: "Software Engineer II",
      location: "San Jose, CA",
      startDate: "2020-06",
      endDate: "2022-05",
      current: false,
      description: "• Authored secure server-side API proxy handlers keeping cloud credentials protected from front-end bundle exposures.\n• Revitalized web UI performance, decreasing asset bundle weight by 40% through strict design boundaries.\n• Teamed up with product designers to map reusable interactive card and visual layout components."
    }
  ],
  projects: [
    {
      id: "proj1",
      title: "Self-Healing Web Diagnostics",
      technologies: "React, Node.js, Tailwind CSS, Recharts",
      description: "- Created a dynamic server state visualizer rendering cluster diagnostic traces across 20 nodes with low latency.\n- Integrated flexible component themes utilizing standard CSS configurations, ensuring cross-browser design continuity.",
      url: "https://github.com/example/diagnostics"
    }
  ],
  skills: [
    "JavaScript", "TypeScript", "React", "Node.js", "Express", "Tailwind CSS", "HTML5/CSS3", "RESTful APIs", "SQL Backend", "Docker", "Git Workflows"
  ],
  certifications: [
    {
      id: "cert1",
      name: "AWS Certified Solutions Architect",
      issuer: "Amazon Web Services (AWS)",
      date: "2024-03"
    }
  ],
  languages: [
    {
      id: "lang1",
      name: "English",
      proficiency: "Native"
    },
    {
      id: "lang2",
      name: "Spanish",
      proficiency: "Conversational"
    }
  ],
  references: [
    {
      id: "ref1",
      name: "Sarah Jenkins",
      company: "VP of Engineering at InnovateTech",
      contact: "sarah.jenkins@example.com",
      relation: "Direct Reporting VP"
    }
  ]
};
