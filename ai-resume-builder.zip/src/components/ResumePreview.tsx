import { ResumeData, ResumeTemplate } from "../types";
import { Mail, Phone, MapPin, Globe, Linkedin, Award, Languages, UserCheck } from "lucide-react";

interface ResumePreviewProps {
  data: ResumeData;
  template: ResumeTemplate;
}

export default function ResumePreview({ data, template }: ResumePreviewProps) {
  const { personalInfo, education, experience, projects, skills, certifications, languages, references } = data;

  // Formatting helpers
  const formatMonth = (value: string) => {
    if (!value) return "Present";
    try {
      const date = new Date(value + "-02"); // add day for cross-browser parsing safety
      return date.toLocaleDateString("en-US", { month: "short", year: "numeric" });
    } catch {
      return value;
    }
  };

  // Inline Hex color variables to strictly prevent color syntax parsing errors in html2canvas
  const colors = {
    white: "#ffffff",
    black: "#000000",
    darkCharcoal: "#111827", // primary text
    darkGray: "#374151",      // headings
    mediumGray: "#4b5563",    // secondary text
    lightGray: "#9ca3af",     // info/subtext
    accentBlue: "#1e3a8a",    // professional main
    accentTeal: "#0d9488",    // modern main
    borderGray: "#d1d5db",    // hard border
    bgLight: "#f3f4f6",       // light tag background
    accentSlate: "#1e293b",   // sidebar dark
  };

  // 1. PROFESSIONAL TEMPLATE
  const renderProfessional = () => {
    return (
      <div style={{ backgroundColor: colors.white, color: colors.darkCharcoal, padding: "40px", fontFamily: "sans-serif" }}>
        {/* Header section with optional profile image */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: `2px solid ${colors.accentBlue}`, paddingBottom: "16px", marginBottom: "20px" }}>
          <div style={{ flex: 1 }}>
            <h1 style={{ fontSize: "28px", fontWeight: "bold", color: colors.accentBlue, letterSpacing: "-0.025em", margin: "0 0 4px 0" }}>
              {personalInfo.fullName || "Your Full Name"}
            </h1>
            <p style={{ fontSize: "16px", fontWeight: "600", color: colors.mediumGray, margin: "0 0 10px 0", textTransform: "uppercase" }}>
              {personalInfo.jobTitle || "Your Professional Title"}
            </p>
            
            {/* Contact details */}
            <div style={{ display: "flex", flexWrap: "wrap", gap: "12px", fontSize: "12px", color: colors.mediumGray }}>
              {personalInfo.email && (
                <span style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  <Mail size={12} style={{ color: colors.accentBlue }} /> {personalInfo.email}
                </span>
              )}
              {personalInfo.phone && (
                <span style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  <Phone size={12} style={{ color: colors.accentBlue }} /> {personalInfo.phone}
                </span>
              )}
              {personalInfo.location && (
                <span style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  <MapPin size={12} style={{ color: colors.accentBlue }} /> {personalInfo.location}
                </span>
              )}
              {personalInfo.website && (
                <span style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  <Globe size={12} style={{ color: colors.accentBlue }} /> {personalInfo.website}
                </span>
              )}
              {personalInfo.linkedin && (
                <span style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  <Linkedin size={12} style={{ color: colors.accentBlue }} /> {personalInfo.linkedin}
                </span>
              )}
            </div>
          </div>

          {/* Profile Picture */}
          {personalInfo.profilePic && (
            <div style={{ marginLeft: "20px", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <img
                src={personalInfo.profilePic}
                alt={personalInfo.fullName}
                referrerPolicy="no-referrer"
                style={{
                  width: "90px",
                  height: "90px",
                  borderRadius: "50%",
                  objectFit: "cover",
                  border: `2px solid ${colors.accentBlue}`,
                  backgroundColor: colors.bgLight
                }}
              />
            </div>
          )}
        </div>

        {/* Executive Summary */}
        {personalInfo.summary && (
          <div style={{ marginBottom: "20px" }}>
            <p style={{ fontSize: "12.5px", lineHeight: "1.6", color: colors.darkCharcoal, margin: 0, textAlign: "justify" }}>
              {personalInfo.summary}
            </p>
          </div>
        )}

        {/* Experience Section */}
        {experience.length > 0 && (
          <div style={{ marginBottom: "22px" }}>
            <h2 style={{ fontSize: "14px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentBlue, borderBottom: `1px solid ${colors.borderGray}`, paddingBottom: "3px", marginBottom: "10px" }}>
              Professional Experience
            </h2>
            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              {experience.map((exp) => (
                <div key={exp.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: "2px" }}>
                    <span style={{ fontSize: "13px", fontWeight: "bold", color: colors.darkCharcoal }}>
                      {exp.role} — <span style={{ fontWeight: "600", color: colors.mediumGray }}>{exp.company}</span>
                    </span>
                    <span style={{ fontSize: "11.5px", color: colors.mediumGray, fontWeight: "500" }}>
                      {formatMonth(exp.startDate)} – {exp.current ? "Present" : formatMonth(exp.endDate)} {exp.location && `| ${exp.location}`}
                    </span>
                  </div>
                  <p style={{ fontSize: "11.5px", lineHeight: "1.5", color: colors.darkCharcoal, margin: 0, whiteSpace: "pre-line" }}>
                    {exp.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects Section */}
        {projects.length > 0 && (
          <div style={{ marginBottom: "22px" }}>
            <h2 style={{ fontSize: "14px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentBlue, borderBottom: `1px solid ${colors.borderGray}`, paddingBottom: "3px", marginBottom: "10px" }}>
              Key Projects
            </h2>
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              {projects.map((proj) => (
                <div key={proj.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: "2px" }}>
                    <span style={{ fontSize: "13px", fontWeight: "bold", color: colors.darkCharcoal }}>
                      {proj.title}
                      {proj.technologies && (
                        <span style={{ fontSize: "11px", fontWeight: "normal", color: colors.mediumGray, marginLeft: "8px", fontStyle: "italic" }}>
                          ({proj.technologies})
                        </span>
                      )}
                    </span>
                    {proj.url && (
                      <span style={{ fontSize: "11px", color: colors.accentBlue }}>
                        {proj.url}
                      </span>
                    )}
                  </div>
                  <p style={{ fontSize: "11.5px", lineHeight: "1.5", color: colors.darkCharcoal, margin: 0, whiteSpace: "pre-line" }}>
                    {proj.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Grid for Education & Skills */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px", marginBottom: "18px" }}>
          {/* Left: Education */}
          {education.length > 0 && (
            <div>
              <h2 style={{ fontSize: "14px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentBlue, borderBottom: `1px solid ${colors.borderGray}`, paddingBottom: "3px", marginBottom: "10px" }}>
                Education
              </h2>
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                {education.map((edu) => (
                  <div key={edu.id}>
                    <div style={{ fontWeight: "bold", fontSize: "12.5px" }}>{edu.degree} {edu.fieldOfStudy && `in ${edu.fieldOfStudy}`}</div>
                    <div style={{ fontSize: "11.5px", color: colors.mediumGray }}>
                      {edu.school} | {formatMonth(edu.startDate)} – {edu.current ? "Present" : formatMonth(edu.endDate)}
                    </div>
                    {edu.description && (
                      <p style={{ fontSize: "11px", color: colors.darkCharcoal, margin: "2px 0 0 0", lineHeight: "1.4" }}>
                        {edu.description}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Right: Skills & Certifications */}
          <div>
            {skills.length > 0 && (
              <div style={{ marginBottom: "14px" }}>
                <h2 style={{ fontSize: "14px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentBlue, borderBottom: `1px solid ${colors.borderGray}`, paddingBottom: "3px", marginBottom: "10px" }}>
                  Skills
                </h2>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "6px" }}>
                  {skills.map((skill, idx) => (
                    <span
                      key={idx}
                      style={{
                        fontSize: "11px",
                        fontWeight: "500",
                        color: colors.darkCharcoal,
                        backgroundColor: colors.bgLight,
                        border: `1px solid ${colors.borderGray}`,
                        padding: "3px 8px",
                        borderRadius: "3px"
                      }}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Certifications inside under Skills */}
            {certifications.length > 0 && (
              <div>
                <h2 style={{ fontSize: "14px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentBlue, borderBottom: `1px solid ${colors.borderGray}`, paddingBottom: "3px", marginBottom: "8px" }}>
                  Certifications
                </h2>
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  {certifications.map((cert) => (
                    <div key={cert.id} style={{ fontSize: "11px", color: colors.darkCharcoal }}>
                      <span style={{ fontWeight: "bold" }}>{cert.name}</span> – <span style={{ color: colors.mediumGray }}>{cert.issuer}</span> ({formatMonth(cert.date)})
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer: Languages, References */}
        {(languages.length > 0 || references.length > 0) && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px", borderTop: `1px solid ${colors.borderGray}`, paddingTop: "12px" }}>
            {/* Languages */}
            {languages.length > 0 ? (
              <div>
                <h3 style={{ fontSize: "12px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentBlue, margin: "0 0 6px 0" }}>
                  Languages
                </h3>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "10px", fontSize: "11px" }}>
                  {languages.map((lang) => (
                    <span key={lang.id} style={{ color: colors.darkCharcoal }}>
                      <span style={{ fontWeight: "600" }}>{lang.name}</span> ({lang.proficiency})
                    </span>
                  ))}
                </div>
              </div>
            ) : <div />}

            {/* References */}
            {references.length > 0 ? (
              <div>
                <h3 style={{ fontSize: "12px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentBlue, margin: "0 0 6px 0" }}>
                  References
                </h3>
                <div style={{ display: "flex", flexDirection: "column", gap: "4px", fontSize: "11px" }}>
                  {references.map((ref) => (
                    <div key={ref.id} style={{ color: colors.darkCharcoal }}>
                      <span style={{ fontWeight: "600" }}>{ref.name}</span> ({ref.relation}), {ref.company} — <span style={{ color: colors.mediumGray }}>{ref.contact}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : <div />}
          </div>
        )}
      </div>
    );
  };

  // 2. MODERN TEMPLATE
  const renderModern = () => {
    return (
      <div style={{ backgroundColor: colors.white, color: colors.darkCharcoal, fontFamily: "sans-serif", display: "grid", gridTemplateColumns: "230px 1fr", minHeight: "840px" }}>
        
        {/* Left Bar (Slate Colors) */}
        <div style={{ backgroundColor: colors.accentSlate, color: colors.white, padding: "30px 20px" }}>
          
          {/* Profile pic inside sidebar */}
          {personalInfo.profilePic && (
            <div style={{ display: "flex", justifyContent: "center", marginBottom: "20px" }}>
              <img
                src={personalInfo.profilePic}
                alt={personalInfo.fullName}
                referrerPolicy="no-referrer"
                style={{
                  width: "110px",
                  height: "110px",
                  borderRadius: "50%",
                  objectFit: "cover",
                  border: `3px solid ${colors.accentTeal}`,
                  backgroundColor: colors.white
                }}
              />
            </div>
          )}

          {/* Name & Title */}
          <div style={{ textAlign: "center", marginBottom: "25px" }}>
            <h1 style={{ fontSize: "20px", fontWeight: "bold", margin: "0 0 4px 0", color: colors.white }}>
              {personalInfo.fullName || "Your Name"}
            </h1>
            <p style={{ fontSize: "12px", fontWeight: "500", color: colors.accentTeal, textTransform: "uppercase", margin: 0 }}>
              {personalInfo.jobTitle || "Your Title"}
            </p>
          </div>

          {/* Contact Details */}
          <div style={{ borderTop: `1px solid rgba(255,255,255,0.15)`, paddingTop: "15px", marginBottom: "25px" }}>
            <h2 style={{ fontSize: "11px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentTeal, letterSpacing: "1px", margin: "0 0 10px 0" }}>
              Contact
            </h2>
            <div style={{ display: "flex", flexDirection: "column", gap: "8px", fontSize: "11px" }}>
              {personalInfo.email && (
                <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <Mail size={11} style={{ shrink: 0, color: colors.accentTeal }} />
                  <span style={{ wordBreak: "break-all" }}>{personalInfo.email}</span>
                </div>
              )}
              {personalInfo.phone && (
                <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <Phone size={11} style={{ shrink: 0, color: colors.accentTeal }} />
                  <span>{personalInfo.phone}</span>
                </div>
              )}
              {personalInfo.location && (
                <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <MapPin size={11} style={{ shrink: 0, color: colors.accentTeal }} />
                  <span>{personalInfo.location}</span>
                </div>
              )}
              {personalInfo.website && (
                <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <Globe size={11} style={{ shrink: 0, color: colors.accentTeal }} />
                  <span style={{ wordBreak: "break-all" }}>{personalInfo.website}</span>
                </div>
              )}
              {personalInfo.linkedin && (
                <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <Linkedin size={11} style={{ shrink: 0, color: colors.accentTeal }} />
                  <span style={{ wordBreak: "break-all" }}>{personalInfo.linkedin}</span>
                </div>
              )}
            </div>
          </div>

          {/* Skills tags in sidebar */}
          {skills.length > 0 && (
            <div style={{ borderTop: `1px solid rgba(255,255,255,0.15)`, paddingTop: "15px", marginBottom: "25px" }}>
              <h2 style={{ fontSize: "11px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentTeal, letterSpacing: "1px", margin: "0 0 10px 0" }}>
                Expertise & Skills
              </h2>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "5px" }}>
                {skills.map((skill, idx) => (
                  <span
                    key={idx}
                    style={{
                      fontSize: "10px",
                      color: colors.white,
                      backgroundColor: "rgba(255,255,255,0.1)",
                      padding: "2px 6px",
                      borderRadius: "2px"
                    }}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Languages */}
          {languages.length > 0 && (
            <div style={{ borderTop: `1px solid rgba(255,255,255,0.15)`, paddingTop: "15px", marginBottom: "25px" }}>
              <h2 style={{ fontSize: "11px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentTeal, letterSpacing: "1px", margin: "0 0 10px 0" }}>
                Languages
              </h2>
              <div style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "11px" }}>
                {languages.map((lang) => (
                  <div key={lang.id}>
                    <p style={{ margin: 0, fontWeight: "600" }}>{lang.name}</p>
                    <p style={{ margin: 0, fontSize: "9.5px", color: colors.lightGray }}>{lang.proficiency}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Certifications inside Sidebar */}
          {certifications.length > 0 && (
            <div style={{ borderTop: `1px solid rgba(255,255,255,0.15)`, paddingTop: "15px" }}>
              <h2 style={{ fontSize: "11px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentTeal, letterSpacing: "1px", margin: "0 0 10px 0" }}>
                Certifications
              </h2>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px", fontSize: "10px" }}>
                {certifications.map((cert) => (
                  <div key={cert.id}>
                    <p style={{ margin: 0, fontWeight: "600" }}>{cert.name}</p>
                    <p style={{ margin: 0, fontSize: "9px", color: colors.lightGray }}>{cert.issuer} ({formatMonth(cert.date)})</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right side content */}
        <div style={{ padding: "35px 25px" }}>
          {/* Executive Summary */}
          {personalInfo.summary && (
            <div style={{ marginBottom: "24px" }}>
              <h2 style={{ fontSize: "13px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentTeal, margin: "0 0 8px 0", letterSpacing: "0.5px" }}>
                Professional Profile
              </h2>
              <p style={{ fontSize: "12px", lineHeight: "1.6", color: colors.darkCharcoal, margin: 0, textAlign: "justify" }}>
                {personalInfo.summary}
              </p>
            </div>
          )}

          {/* Professional Work Experience */}
          {experience.length > 0 && (
            <div style={{ marginBottom: "26px" }}>
              <h2 style={{ fontSize: "13px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentTeal, margin: "0 0 12px 0", letterSpacing: "0.5px", borderBottom: `1.5px solid ${colors.bgLight}`, paddingBottom: "4px" }}>
                Work History
              </h2>
              <div style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
                {experience.map((exp) => (
                  <div key={exp.id}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                      <span style={{ fontSize: "13px", fontWeight: "bold", color: colors.accentSlate }}>
                        {exp.role} <span style={{ color: colors.accentTeal }}>@ {exp.company}</span>
                      </span>
                      <span style={{ fontSize: "11px", color: colors.mediumGray, fontWeight: "500" }}>
                        {formatMonth(exp.startDate)} – {exp.current ? "Present" : formatMonth(exp.endDate)}
                      </span>
                    </div>
                    {exp.location && <div style={{ fontSize: "11px", color: colors.lightGray, marginBottom: "4px" }}>{exp.location}</div>}
                    <p style={{ fontSize: "11.5px", lineHeight: "1.5", color: colors.darkCharcoal, margin: "2px 0 0 0", whiteSpace: "pre-line" }}>
                      {exp.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Projects */}
          {projects.length > 0 && (
            <div style={{ marginBottom: "26px" }}>
              <h2 style={{ fontSize: "13px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentTeal, margin: "0 0 12px 0", letterSpacing: "0.5px", borderBottom: `1.5px solid ${colors.bgLight}`, paddingBottom: "4px" }}>
                Featured Projects
              </h2>
              <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                {projects.map((proj) => (
                  <div key={proj.id}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                      <span style={{ fontSize: "12.5px", fontWeight: "bold", color: colors.accentSlate }}>
                        {proj.title}
                      </span>
                      {proj.url && <span style={{ fontSize: "11px", color: colors.accentTeal }}>{proj.url}</span>}
                    </div>
                    {proj.technologies && (
                      <div style={{ fontSize: "10.5px", color: colors.mediumGray, margin: "2px 0 4px 0", fontStyle: "italic" }}>
                        Stack: {proj.technologies}
                      </div>
                    )}
                    <p style={{ fontSize: "11.5px", lineHeight: "1.5", color: colors.darkCharcoal, margin: 0, whiteSpace: "pre-line" }}>
                      {proj.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Education */}
          {education.length > 0 && (
            <div style={{ marginBottom: "22px" }}>
              <h2 style={{ fontSize: "13px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentTeal, margin: "0 0 12px 0", letterSpacing: "0.5px", borderBottom: `1.5px solid ${colors.bgLight}`, paddingBottom: "4px" }}>
                Academic Background
              </h2>
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                {education.map((edu) => (
                  <div key={edu.id}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                      <span style={{ fontSize: "12.5px", fontWeight: "bold", color: colors.accentSlate }}>
                        {edu.degree} {edu.fieldOfStudy && `in ${edu.fieldOfStudy}`}
                      </span>
                      <span style={{ fontSize: "11px", color: colors.mediumGray }}>
                        {formatMonth(edu.startDate)} – {edu.current ? "Present" : formatMonth(edu.endDate)}
                      </span>
                    </div>
                    <div style={{ fontSize: "11px", color: colors.mediumGray }}>{edu.school}</div>
                    {edu.description && (
                      <p style={{ fontSize: "11px", color: colors.darkCharcoal, margin: "2px 0 0 0" }}>
                        {edu.description}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* References */}
          {references.length > 0 && (
            <div style={{ borderTop: `1px solid ${colors.bgLight}`, paddingTop: "14px" }}>
              <h2 style={{ fontSize: "12px", fontWeight: "bold", textTransform: "uppercase", color: colors.accentTeal, margin: "0 0 8px 0" }}>
                References
              </h2>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                {references.map((ref) => (
                  <div key={ref.id} style={{ fontSize: "11px", color: colors.darkCharcoal }}>
                    <p style={{ margin: 0, fontWeight: "bold" }}>{ref.name} <span style={{ color: colors.mediumGray, fontWeight: "normal" }}>({ref.relation})</span></p>
                    <p style={{ margin: 0, color: colors.mediumGray }}>{ref.company}</p>
                    <p style={{ margin: 0, color: colors.accentTeal }}>{ref.contact}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      </div>
    );
  };

  // 3. MINIMAL TEMPLATE
  const renderMinimal = () => {
    return (
      <div style={{ backgroundColor: colors.white, color: colors.darkCharcoal, padding: "40px", fontFamily: "sans-serif" }}>
        
        {/* Simple top header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "30px", borderBottom: `1px solid ${colors.bgLight}`, paddingBottom: "20px" }}>
          <div>
            <h1 style={{ fontSize: "32px", fontWeight: "300", letterSpacing: "-0.04em", color: colors.darkCharcoal, margin: "0 0 4px 0" }}>
              {personalInfo.fullName || "Your Full Name"}
            </h1>
            <p style={{ fontSize: "14px", fontWeight: "500", color: colors.mediumGray, margin: "0 0 15px 0" }}>
              {personalInfo.jobTitle || "Your Title"}
            </p>

            <div style={{ display: "flex", flexWrap: "wrap", gap: "16px", fontSize: "11.5px", color: colors.lightGray }}>
              {personalInfo.email && <span>{personalInfo.email}</span>}
              {personalInfo.phone && <span>{personalInfo.phone}</span>}
              {personalInfo.location && <span>{personalInfo.location}</span>}
              {personalInfo.website && <span>{personalInfo.website}</span>}
              {personalInfo.linkedin && <span>{personalInfo.linkedin}</span>}
            </div>
          </div>

          {/* Profile Picture Minimal */}
          {personalInfo.profilePic && (
            <div>
              <img
                src={personalInfo.profilePic}
                alt={personalInfo.fullName}
                referrerPolicy="no-referrer"
                style={{
                  width: "80px",
                  height: "80px",
                  borderRadius: "8px", // sleek soft box
                  objectFit: "cover",
                  border: `1px solid ${colors.borderGray}`,
                  backgroundColor: colors.bgLight
                }}
              />
            </div>
          )}
        </div>

        {/* Executive Summary */}
        {personalInfo.summary && (
          <div style={{ marginBottom: "26px" }}>
            <p style={{ fontSize: "12.5px", lineHeight: "1.6", color: colors.mediumGray, margin: 0, fontWeight: "400", textAlign: "justify" }}>
              {personalInfo.summary}
            </p>
          </div>
        )}

        {/* Work history */}
        {experience.length > 0 && (
          <div style={{ marginBottom: "26px" }}>
            <h2 style={{ fontSize: "12px", fontWeight: "600", textTransform: "uppercase", color: colors.darkCharcoal, letterSpacing: "1px", borderBottom: `1px solid ${colors.darkCharcoal}`, paddingBottom: "2px", marginBottom: "12px" }}>
              Experience
            </h2>
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              {experience.map((exp) => (
                <div key={exp.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: "2px" }}>
                    <span style={{ fontSize: "12.5px", fontWeight: "bold" }}>
                      {exp.role} <span style={{ fontWeight: "normal", color: colors.lightGray }}>at</span> {exp.company}
                    </span>
                    <span style={{ fontSize: "11px", color: colors.mediumGray }}>
                      {formatMonth(exp.startDate)} – {exp.current ? "Present" : formatMonth(exp.endDate)}
                    </span>
                  </div>
                  {exp.location && <div style={{ fontSize: "10.5px", color: colors.lightGray, marginBottom: "3px" }}>{exp.location}</div>}
                  <p style={{ fontSize: "11.5px", lineHeight: "1.5", color: colors.mediumGray, margin: 0, whiteSpace: "pre-line" }}>
                    {exp.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects */}
        {projects.length > 0 && (
          <div style={{ marginBottom: "26px" }}>
            <h2 style={{ fontSize: "12px", fontWeight: "600", textTransform: "uppercase", color: colors.darkCharcoal, letterSpacing: "1px", borderBottom: `1px solid ${colors.darkCharcoal}`, paddingBottom: "2px", marginBottom: "12px" }}>
              Selected Projects
            </h2>
            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              {projects.map((proj) => (
                <div key={proj.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                    <span style={{ fontSize: "12.5px", fontWeight: "bold" }}>{proj.title}</span>
                    {proj.url && <span style={{ fontSize: "11px", color: colors.mediumGray }}>{proj.url}</span>}
                  </div>
                  {proj.technologies && (
                    <div style={{ fontSize: "10px", color: colors.lightGray, marginBottom: "3px" }}>
                      Technologies: {proj.technologies}
                    </div>
                  )}
                  <p style={{ fontSize: "11.5px", lineHeight: "1.5", color: colors.mediumGray, margin: 0, whiteSpace: "pre-line" }}>
                    {proj.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Horizontal Split for Skills & Education */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "25px", marginBottom: "20px" }}>
          
          {/* Education */}
          {education.length > 0 && (
            <div>
              <h2 style={{ fontSize: "12px", fontWeight: "600", textTransform: "uppercase", color: colors.darkCharcoal, letterSpacing: "1px", borderBottom: `1px solid ${colors.darkCharcoal}`, paddingBottom: "2px", marginBottom: "12px" }}>
                Education
              </h2>
              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {education.map((edu) => (
                  <div key={edu.id}>
                    <div style={{ fontWeight: "bold", fontSize: "12px" }}>{edu.degree} in {edu.fieldOfStudy}</div>
                    <div style={{ fontSize: "11px", color: colors.mediumGray }}>
                      {edu.school} | {formatMonth(edu.startDate)} – {edu.current ? "Present" : formatMonth(edu.endDate)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Skills */}
          {skills.length > 0 && (
            <div>
              <h2 style={{ fontSize: "12px", fontWeight: "600", textTransform: "uppercase", color: colors.darkCharcoal, letterSpacing: "1px", borderBottom: `1px solid ${colors.darkCharcoal}`, paddingBottom: "2px", marginBottom: "12px" }}>
                Skills
              </h2>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "4px" }}>
                {skills.map((skill, idx) => (
                  <span
                    key={idx}
                    style={{
                      fontSize: "11px",
                      color: colors.darkCharcoal,
                      border: `1px solid ${colors.borderGray}`,
                      padding: "2px 6px",
                      borderRadius: "2px"
                    }}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Certifications & Languages */}
        {(certifications.length > 0 || languages.length > 0 || references.length > 0) && (
          <div style={{ borderTop: `1px solid ${colors.bgLight}`, paddingTop: "14px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
            
            {/* Certifications */}
            {certifications.length > 0 && (
              <div>
                <h3 style={{ fontSize: "11px", fontWeight: "bold", textTransform: "uppercase", margin: "0 0 6px 0" }}>Certifications</h3>
                <div style={{ display: "flex", flexDirection: "column", gap: "4px", fontSize: "11px", color: colors.mediumGray }}>
                  {certifications.map((cert) => (
                    <div key={cert.id}>
                      <span style={{ fontWeight: "bold", color: colors.darkCharcoal }}>{cert.name}</span> – {cert.issuer} ({formatMonth(cert.date)})
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Languages & References group block */}
            <div>
              {languages.length > 0 && (
                <div style={{ marginBottom: "10px" }}>
                  <h3 style={{ fontSize: "11px", fontWeight: "bold", textTransform: "uppercase", margin: "0 0 6px 0" }}>Languages</h3>
                  <div style={{ fontSize: "11px", color: colors.mediumGray }}>
                    {languages.map((l) => `${l.name} (${l.proficiency})`).join(", ")}
                  </div>
                </div>
              )}

              {references.length > 0 && (
                <div>
                  <h3 style={{ fontSize: "11px", fontWeight: "bold", textTransform: "uppercase", margin: "0 0 6px 0" }}>References</h3>
                  <div style={{ display: "flex", flexDirection: "column", gap: "4px", fontSize: "10.5px", color: colors.mediumGray }}>
                    {references.map((r) => (
                      <div key={r.id}>
                        <span style={{ fontWeight: "bold", color: colors.darkCharcoal }}>{r.name}</span> ({r.relation}), {r.company} – {r.contact}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

          </div>
        )}

      </div>
    );
  };

  const getTemplateRenderer = () => {
    switch (template) {
      case ResumeTemplate.MODERN:
        return renderModern();
      case ResumeTemplate.MINIMAL:
        return renderMinimal();
      case ResumeTemplate.PROFESSIONAL:
      default:
        return renderProfessional();
    }
  };

  return (
    <div
      id="resume-print-preview"
      style={{
        boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)",
        borderRadius: "8px",
        overflow: "hidden",
        width: "100%",
        maxWidth: "800px",
        margin: "0 auto",
        backgroundColor: colors.white
      }}
    >
      {getTemplateRenderer()}
    </div>
  );
}
