import React, { useState } from "react";
import { ResumeData, Education, Experience, Project, Certification, Language, Reference } from "../types";
import {
  User, Briefcase, GraduationCap, Code, FolderGit, Award, Globe, HeartHandshake,
  Sparkles, Trash2, Plus, ArrowRight, Upload, X, AlertCircle, Info, CheckCircle
} from "lucide-react";

interface ResumeFormProps {
  data: ResumeData;
  onChange: (newData: ResumeData) => void;
}

export default function ResumeForm({ data, onChange }: ResumeFormProps) {
  const { personalInfo, education, experience, projects, skills, certifications, languages, references } = data;

  // Active accordion state
  const [activeTab, setActiveTab] = useState<string>("personal");

  // AI loading and diagnostic states
  const [loading, setLoading] = useState<{ [key: string]: boolean }>({});
  const [aiSkillFocus, setAiSkillFocus] = useState<string>("");
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiSuccessMsg, setAiSuccessMsg] = useState<string | null>(null);

  // Manual skill entry chip state
  const [newSkill, setNewSkill] = useState<string>("");

  // Real-time validations
  const getErrors = () => {
    const errorList: { field: string; msg: string }[] = [];

    if (!personalInfo.fullName.trim()) {
      errorList.push({ field: "fullName", msg: "Full Name is required" });
    }
    if (!personalInfo.email.trim()) {
      errorList.push({ field: "email", msg: "Email Address is required" });
    } else if (!/\S+@\S+\.\S+/.test(personalInfo.email)) {
      errorList.push({ field: "email", msg: "Email must be a valid email format" });
    }
    if (!personalInfo.phone.trim()) {
      errorList.push({ field: "phone", msg: "Phone Number is required" });
    } else if (personalInfo.phone.trim().length < 7) {
      errorList.push({ field: "phone", msg: "Please enter a valid phone number" });
    }

    return errorList;
  };

  const validationErrors = getErrors();

  // Helper trigger for Express backend Gemini Generation
  const triggerAiGen = async (type: "summary" | "skills" | "project", payload: any, callback: (resultText: string) => void) => {
    setLoading(prev => ({ ...prev, [type]: true }));
    setAiError(null);
    setAiSuccessMsg(null);
    try {
      const response = await fetch("/api/ai/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ type, payload }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP error ${response.status}`);
      }

      const resJson = await response.json();
      if (resJson.text) {
        callback(resJson.text);
        setAiSuccessMsg(`Success! AI successfully generated your ${type}.`);
        setTimeout(() => setAiSuccessMsg(null), 4000);
      } else {
        throw new Error("Empty AI result text returned");
      }
    } catch (e: any) {
      console.error(e);
      setAiError(e.message || "Failed to generate AI contents. Check if Gemini Secrets API Key is configured.");
    } finally {
      setLoading(prev => ({ ...prev, [type]: false }));
    }
  };

  // 1. Personal Information Handlers
  const handlePersonalChange = (key: keyof typeof personalInfo, value: string) => {
    onChange({
      ...data,
      personalInfo: {
        ...personalInfo,
        [key]: value
      }
    });
  };

  const handleProfileImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const { compressImage } = await import("../utils");
      const compressedBase64 = await compressImage(file);
      onChange({
        ...data,
        personalInfo: {
          ...personalInfo,
          profilePic: compressedBase64
        }
      });
      setAiSuccessMsg("Profile image compressed & saved.");
      setTimeout(() => setAiSuccessMsg(null), 3000);
    } catch (err: any) {
      setAiError("Could not process the uploaded photo. Try a smaller file.");
    }
  };

  const handleRemoveProfilePic = () => {
    onChange({
      ...data,
      personalInfo: {
        ...personalInfo,
        profilePic: ""
      }
    });
  };

  const handleAiAutoSummary = () => {
    const payload = {
      title: personalInfo.jobTitle,
      skills: skills.slice(0, 8).join(", "),
      experience: experience.slice(0, 1).map(e => `${e.role} at ${e.company}`).join(". ")
    };

    triggerAiGen("summary", payload, (text) => {
      handlePersonalChange("summary", text);
    });
  };

  // 2. Experience Handlers
  const handleExperienceChange = (id: string, key: keyof Experience, value: any) => {
    const updated = experience.map(exp => {
      if (exp.id === id) {
        return { ...exp, [key]: value };
      }
      return exp;
    });
    onChange({ ...data, experience: updated });
  };

  const addExperience = () => {
    const newItem: Experience = {
      id: Math.random().toString(36).substring(2, 9),
      company: "",
      role: "",
      location: "",
      startDate: "",
      endDate: "",
      current: false,
      description: ""
    };
    onChange({ ...data, experience: [...experience, newItem] });
  };

  const deleteExperience = (id: string) => {
    onChange({ ...data, experience: experience.filter(item => item.id !== id) });
  };

  // 3. Education Handlers
  const handleEducationChange = (id: string, key: keyof Education, value: any) => {
    const updated = education.map(edu => {
      if (edu.id === id) {
        return { ...edu, [key]: value };
      }
      return edu;
    });
    onChange({ ...data, education: updated });
  };

  const addEducation = () => {
    const newItem: Education = {
      id: Math.random().toString(36).substring(2, 9),
      school: "",
      degree: "",
      fieldOfStudy: "",
      startDate: "",
      endDate: "",
      current: false,
      description: ""
    };
    onChange({ ...data, education: [...education, newItem] });
  };

  const deleteEducation = (id: string) => {
    onChange({ ...data, education: education.filter(item => item.id !== id) });
  };

  // 4. Skills Tags Handlers
  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newSkill.trim();
    if (trimmed && !skills.includes(trimmed)) {
      onChange({ ...data, skills: [...skills, trimmed] });
      setNewSkill("");
    }
  };

  const deleteSkill = (skillToDelete: string) => {
    onChange({ ...data, skills: skills.filter(item => item !== skillToDelete) });
  };

  const handleAiSkillSuggest = () => {
    const payload = {
      title: personalInfo.jobTitle || "Full Stack Developer",
      skills: skills.join(", "),
      focus: aiSkillFocus
    };

    triggerAiGen("skills", payload, (text) => {
      try {
        const parsed: string[] = JSON.parse(text);
        if (Array.isArray(parsed)) {
          // Merge unique skills
          const updatedSkills = Array.from(new Set([...skills, ...parsed]));
          onChange({ ...data, skills: updatedSkills });
        }
      } catch {
        // Fallback for simple comma separated list if JSON fails
        const items = text.replace(/[\[\]"]/g, "").split(",").map(i => i.trim()).filter(Boolean);
        if (items.length > 0) {
          const updatedSkills = Array.from(new Set([...skills, ...items]));
          onChange({ ...data, skills: updatedSkills });
        }
      }
    });
  };

  // 5. Projects Handlers
  const handleProjectChange = (id: string, key: keyof Project, value: string) => {
    const updated = projects.map(proj => {
      if (proj.id === id) {
        return { ...proj, [key]: value };
      }
      return proj;
    });
    onChange({ ...data, projects: updated });
  };

  const addProject = () => {
    const newItem: Project = {
      id: Math.random().toString(36).substring(2, 9),
      title: "",
      technologies: "",
      description: "",
      url: ""
    };
    onChange({ ...data, projects: [...projects, newItem] });
  };

  const deleteProject = (id: string) => {
    onChange({ ...data, projects: projects.filter(item => item.id !== id) });
  };

  const handleAiProjectBullets = (id: string, projTitle: string, projTech: string, projDesc: string) => {
    const payload = {
      projectTitle: projTitle || "Personal Web Application",
      technologies: projTech || "Modern Tech stack",
      description: projDesc
    };

    triggerAiGen("project", payload, (text) => {
      handleProjectChange(id, "description", text);
    });
  };

  // 6. Certifications Handlers
  const handleCertChange = (id: string, key: keyof Certification, value: string) => {
    const updated = certifications.map(cert => {
      if (cert.id === id) {
        return { ...cert, [key]: value };
      }
      return cert;
    });
    onChange({ ...data, certifications: updated });
  };

  const addCert = () => {
    const newItem: Certification = {
      id: Math.random().toString(36).substring(2, 9),
      name: "",
      issuer: "",
      date: ""
    };
    onChange({ ...data, certifications: [...certifications, newItem] });
  };

  const deleteCert = (id: string) => {
    onChange({ ...data, certifications: certifications.filter(item => item.id !== id) });
  };

  // 7. Languages Handlers
  const handleLanguageChange = (id: string, key: keyof Language, value: string) => {
    const updated = languages.map(lang => {
      if (lang.id === id) {
        return { ...lang, [key]: value };
      }
      return lang;
    });
    onChange({ ...data, languages: updated });
  };

  const addLanguage = () => {
    const newItem: Language = {
      id: Math.random().toString(36).substring(2, 9),
      name: "",
      proficiency: "Fluent"
    };
    onChange({ ...data, languages: [...languages, newItem] });
  };

  const deleteLanguage = (id: string) => {
    onChange({ ...data, languages: languages.filter(item => item.id !== id) });
  };

  // 8. References Handlers
  const handleReferenceChange = (id: string, key: keyof Reference, value: string) => {
    const updated = references.map(ref => {
      if (ref.id === id) {
        return { ...ref, [key]: value };
      }
      return ref;
    });
    onChange({ ...data, references: updated });
  };

  const addReference = () => {
    const newItem: Reference = {
      id: Math.random().toString(36).substring(2, 9),
      name: "",
      company: "",
      contact: "",
      relation: "Reporting Manager"
    };
    onChange({ ...data, references: [...references, newItem] });
  };

  const deleteReference = (id: string) => {
    onChange({ ...data, references: references.filter(item => item.id !== id) });
  };

  return (
    <div className="space-y-4">
      {/* Real-time Integrity Check Widget */}
      <div className="p-4 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/30 transition-colors">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-2 flex items-center gap-1.5">
          <Info size={14} className="text-blue-500" /> Form Integrity Checklist
        </h3>
        <div className="space-y-1.5">
          {validationErrors.length > 0 ? (
            validationErrors.map((err, index) => (
              <div key={index} className="flex items-start gap-1.5 text-xs text-red-600 dark:text-red-400">
                <AlertCircle size={13} className="mt-0.5 shrink-0" />
                <span>{err.msg}</span>
              </div>
            ))
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
              <CheckCircle size={14} className="shrink-0" />
              <span>All mandatory ATS criteria met. Ready for professional download.</span>
            </div>
          )}
        </div>
      </div>

      {/* AI Success / Error Toast notification inside form */}
      {aiError && (
        <div className="p-3 text-xs bg-red-100 dark:bg-red-950/40 text-red-700 dark:text-red-300 rounded-lg flex items-start gap-2 border border-red-200 dark:border-red-900 animate-pulse">
          <AlertCircle size={14} className="mt-0.5 shrink-0" />
          <span>{aiError}</span>
        </div>
      )}
      {aiSuccessMsg && (
        <div className="p-3 text-xs bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 rounded-lg flex items-start gap-2 border border-emerald-200 dark:border-emerald-900">
          <CheckCircle size={14} className="mt-0.5 shrink-0" />
          <span>{aiSuccessMsg}</span>
        </div>
      )}

      {/* Accordion Panels */}

      {/* Accordion Tab 1: Personal info */}
      <div className="border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden bg-white dark:bg-gray-900">
        <button
          onClick={() => setActiveTab(activeTab === "personal" ? "" : "personal")}
          className="w-full flex items-center justify-between p-4 font-semibold text-left text-gray-800 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all"
        >
          <div className="flex items-center gap-3">
            <User size={18} className="text-indigo-500" />
            <span>Personal Information</span>
          </div>
          <span className="text-gray-400 font-normal">{activeTab === "personal" ? "Collapse" : "Expand"}</span>
        </button>

        {activeTab === "personal" && (
          <div className="p-4 border-t border-gray-100 dark:border-gray-800 space-y-4">
            
            {/* Profile Picture Upload row */}
            <div className="sm:flex items-center gap-4 p-3 bg-gray-50 dark:bg-gray-800/40 rounded-lg">
              <div className="flex-shrink-0 flex justify-center mb-3 sm:mb-0">
                {personalInfo.profilePic ? (
                  <div className="relative">
                    <img
                      src={personalInfo.profilePic}
                      alt="Crop Preview"
                      referrerPolicy="no-referrer"
                      className="w-20 h-20 rounded-full object-cover border-2 border-indigo-500 bg-white"
                    />
                    <button
                      type="button"
                      onClick={handleRemoveProfilePic}
                      className="absolute -top-1 -right-1 p-1 rounded-full bg-red-600 text-white hover:bg-red-700 shadow-md transition-colors"
                      title="Remove image"
                    >
                      <X size={12} />
                    </button>
                  </div>
                ) : (
                  <div className="w-20 h-20 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center text-gray-400 dark:text-gray-500 border border-dashed border-gray-300 dark:border-gray-700">
                    <User size={30} />
                  </div>
                )}
              </div>
              <div className="flex-grow space-y-1 text-center sm:text-left">
                <p className="text-xs font-semibold text-gray-700 dark:text-gray-300">Profile Picture</p>
                <p className="text-[11px] text-gray-500 dark:text-gray-400">JPG/PNG. Picture resizes to professional compact dimensions.</p>
                <div className="flex justify-center sm:justify-start pt-1.5">
                  <label className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg cursor-pointer transition-colors shadow-sm">
                    <Upload size={13} />
                    <span>Upload Image</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleProfileImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={personalInfo.fullName}
                  onChange={(e) => handlePersonalChange("fullName", e.target.value)}
                  placeholder="e.g. Alex Rivera"
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  Target Job Title
                </label>
                <input
                  type="text"
                  value={personalInfo.jobTitle}
                  onChange={(e) => handlePersonalChange("jobTitle", e.target.value)}
                  placeholder="e.g. Senior Full-Stack Engineer"
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={personalInfo.email}
                  onChange={(e) => handlePersonalChange("email", e.target.value)}
                  placeholder="e.g. alex.rivera@example.com"
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  Phone Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={personalInfo.phone}
                  onChange={(e) => handlePersonalChange("phone", e.target.value)}
                  placeholder="e.g. +1 (555) 012-3456"
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  Location (City, State)
                </label>
                <input
                  type="text"
                  value={personalInfo.location}
                  onChange={(e) => handlePersonalChange("location", e.target.value)}
                  placeholder="e.g. San Francisco, CA"
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  Personal Website / Link
                </label>
                <input
                  type="text"
                  value={personalInfo.website}
                  onChange={(e) => handlePersonalChange("website", e.target.value)}
                  placeholder="e.g. https://alexrivera.dev"
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  LinkedIn Profile URL
                </label>
                <input
                  type="text"
                  value={personalInfo.linkedin}
                  onChange={(e) => handlePersonalChange("linkedin", e.target.value)}
                  placeholder="e.g. https://linkedin.com/in/alexrivera-dev"
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              {/* Professional summary block */}
              <div className="sm:col-span-2 border-t border-gray-100 dark:border-gray-800 pt-4">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
                    Professional Summary
                  </label>
                  <button
                    type="button"
                    onClick={handleAiAutoSummary}
                    disabled={loading.summary}
                    className="flex items-center gap-1 text-[11px] font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 dark:disabled:bg-gray-800 px-2.5 py-1 rounded-lg transition-all shadow-sm cursor-pointer"
                  >
                    <Sparkles size={11} className={loading.summary ? "animate-spin" : ""} />
                    <span>{loading.summary ? "AI Generating..." : "AI Auto-Write Summary"}</span>
                  </button>
                </div>
                <textarea
                  rows={4}
                  value={personalInfo.summary}
                  onChange={(e) => handlePersonalChange("summary", e.target.value)}
                  placeholder="Compelling cover highlight. Write an outstanding statement or use the AI Assist trigger above to compile custom professional profiles instantly..."
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-y"
                />
              </div>
            </div>

          </div>
        )}
      </div>

      {/* Accordion Tab 2: Work Experience */}
      <div className="border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden bg-white dark:bg-gray-900">
        <button
          onClick={() => setActiveTab(activeTab === "experience" ? "" : "experience")}
          className="w-full flex items-center justify-between p-4 font-semibold text-left text-gray-800 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all"
        >
          <div className="flex items-center gap-3">
            <Briefcase size={18} className="text-amber-500" />
            <span>Work Experience ({experience.length})</span>
          </div>
          <span className="text-gray-400 font-normal">{activeTab === "experience" ? "Collapse" : "Expand"}</span>
        </button>

        {activeTab === "experience" && (
          <div className="p-4 border-t border-gray-100 dark:border-gray-800 space-y-4">
            {experience.length === 0 ? (
              <div className="text-center py-6 text-xs text-gray-400 dark:text-gray-500 font-medium">
                No experience listed. Click below to add a job entry.
              </div>
            ) : (
              <div className="space-y-4 divide-y divide-gray-100 dark:divide-gray-800">
                {experience.map((exp, index) => (
                  <div key={exp.id} className={index > 0 ? "pt-4 space-y-3" : "space-y-3"}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Job Entry #{index + 1}</span>
                      <button
                        type="button"
                        onClick={() => deleteExperience(exp.id)}
                        className="flex items-center gap-1 px-2 py-1 rounded bg-red-50 hover:bg-red-100 text-red-600 dark:bg-red-950/20 dark:hover:bg-red-950/40 text-[10.5px] font-semibold transition-colors shadow-sm"
                      >
                        <Trash2 size={11} /> Remove
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5">Company Name</label>
                        <input
                          type="text"
                          value={exp.company}
                          onChange={(e) => handleExperienceChange(exp.id, "company", e.target.value)}
                          placeholder="e.g. InnovateTech Solutions"
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5">Job Role / Title</label>
                        <input
                          type="text"
                          value={exp.role}
                          onChange={(e) => handleExperienceChange(exp.id, "role", e.target.value)}
                          placeholder="e.g. Lead Full-Stack Web Developer"
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5">Location</label>
                        <input
                          type="text"
                          value={exp.location}
                          onChange={(e) => handleExperienceChange(exp.id, "location", e.target.value)}
                          placeholder="e.g. San Francisco, CA"
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5">Start (YYYY-MM)</label>
                          <input
                            type="month"
                            value={exp.startDate}
                            onChange={(e) => handleExperienceChange(exp.id, "startDate", e.target.value)}
                            className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5">End (YYYY-MM)</label>
                          <input
                            type="month"
                            value={exp.endDate}
                            disabled={exp.current}
                            onChange={(e) => handleExperienceChange(exp.id, "endDate", e.target.value)}
                            className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 disabled:opacity-50 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          />
                        </div>
                      </div>

                      <div className="sm:col-span-2 flex items-center gap-2 py-1">
                        <input
                          type="checkbox"
                          id={`current-exp-${exp.id}`}
                          checked={exp.current}
                          onChange={(e) => handleExperienceChange(exp.id, "current", e.target.checked)}
                          className="rounded text-indigo-600 focus:ring-indigo-500"
                        />
                        <label htmlFor={`current-exp-${exp.id}`} className="text-xs font-medium text-gray-700 dark:text-gray-300 cursor-pointer">
                          I currently work at this company
                        </label>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5">
                          Job Activities & Descriptions
                        </label>
                        <textarea
                          rows={3}
                          value={exp.description}
                          onChange={(e) => handleExperienceChange(exp.id, "description", e.target.value)}
                          placeholder="Use concise bullet highlights starting with '• ' or '- ' to describe achievements (ATS compliant)..."
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-sans"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={addExperience}
              className="w-full flex items-center justify-center gap-1.5 py-2 border-2 border-dashed border-gray-200 dark:border-gray-800 hover:border-indigo-400 dark:hover:border-indigo-800 rounded-lg text-indigo-600 text-xs font-semibold hover:bg-indigo-50/50 dark:hover:bg-indigo-950/10 cursor-pointer transition-all"
            >
              <Plus size={14} /> Add Experience Record
            </button>
          </div>
        )}
      </div>

      {/* Accordion Tab 3: Education */}
      <div className="border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden bg-white dark:bg-gray-900">
        <button
          onClick={() => setActiveTab(activeTab === "education" ? "" : "education")}
          className="w-full flex items-center justify-between p-4 font-semibold text-left text-gray-800 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all"
        >
          <div className="flex items-center gap-3">
            <GraduationCap size={18} className="text-indigo-500" />
            <span>Academic Background ({education.length})</span>
          </div>
          <span className="text-gray-400 font-normal">{activeTab === "education" ? "Collapse" : "Expand"}</span>
        </button>

        {activeTab === "education" && (
          <div className="p-4 border-t border-gray-100 dark:border-gray-800 space-y-4">
            {education.length === 0 ? (
              <div className="text-center py-6 text-xs text-gray-400 dark:text-gray-500 font-medium">
                No education history listed. Click below to add an entry.
              </div>
            ) : (
              <div className="space-y-4 divide-y divide-gray-100 dark:divide-gray-800">
                {education.map((edu, index) => (
                  <div key={edu.id} className={index > 0 ? "pt-4 space-y-3" : "space-y-3"}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Academic Entry #{index + 1}</span>
                      <button
                        type="button"
                        onClick={() => deleteEducation(edu.id)}
                        className="flex items-center gap-1 px-2 py-1 rounded bg-red-50 hover:bg-red-100 text-red-600 dark:bg-red-950/20 dark:hover:bg-red-950/40 text-[10.5px] font-semibold transition-colors shadow-sm"
                      >
                        <Trash2 size={11} /> Remove
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5 font-medium">School / University</label>
                        <input
                          type="text"
                          value={edu.school}
                          onChange={(e) => handleEducationChange(edu.id, "school", e.target.value)}
                          placeholder="e.g. UC Berkeley"
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5 font-medium">Degree Level</label>
                        <input
                          type="text"
                          value={edu.degree}
                          onChange={(e) => handleEducationChange(edu.id, "degree", e.target.value)}
                          placeholder="e.g. Bachelor of Science"
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5 font-medium">Field of Study</label>
                        <input
                          type="text"
                          value={edu.fieldOfStudy}
                          onChange={(e) => handleEducationChange(edu.id, "fieldOfStudy", e.target.value)}
                          placeholder="e.g. Computer Science"
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5 font-medium">Start Year/Month</label>
                          <input
                            type="month"
                            value={edu.startDate}
                            onChange={(e) => handleEducationChange(edu.id, "startDate", e.target.value)}
                            className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5 font-medium">End Year/Month</label>
                          <input
                            type="month"
                            value={edu.endDate}
                            disabled={edu.current}
                            onChange={(e) => handleEducationChange(edu.id, "endDate", e.target.value)}
                            className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 disabled:opacity-50 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          />
                        </div>
                      </div>

                      <div className="sm:col-span-2 flex items-center gap-2 py-1">
                        <input
                          type="checkbox"
                          id={`current-edu-${edu.id}`}
                          checked={edu.current}
                          onChange={(e) => handleEducationChange(edu.id, "current", e.target.checked)}
                          className="rounded text-indigo-600 focus:ring-indigo-500"
                        />
                        <label htmlFor={`current-edu-${edu.id}`} className="text-xs font-medium text-gray-700 dark:text-gray-300 cursor-pointer">
                          I am currently studying here
                        </label>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5 font-medium">Special Highlights, Honors or GPA</label>
                        <input
                          type="text"
                          value={edu.description}
                          onChange={(e) => handleEducationChange(edu.id, "description", e.target.value)}
                          placeholder="e.g. Graduated with Honors. Specialization in Intelligent Web Systems."
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={addEducation}
              className="w-full flex items-center justify-center gap-1.5 py-2 border-2 border-dashed border-gray-200 dark:border-gray-800 hover:border-indigo-400 dark:hover:border-indigo-800 rounded-lg text-indigo-600 text-xs font-semibold hover:bg-indigo-50/50 dark:hover:bg-indigo-950/10 cursor-pointer transition-all"
            >
              <Plus size={14} /> Add Academic Record
            </button>
          </div>
        )}
      </div>

      {/* Accordion Tab 4: Skills tag management & AI Suggestions */}
      <div className="border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden bg-white dark:bg-gray-900">
        <button
          onClick={() => setActiveTab(activeTab === "skills" ? "" : "skills")}
          className="w-full flex items-center justify-between p-4 font-semibold text-left text-gray-800 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all"
        >
          <div className="flex items-center gap-3">
            <Code size={18} className="text-emerald-500" />
            <span>Skills & Expertise ({skills.length})</span>
          </div>
          <span className="text-gray-400 font-normal">{activeTab === "skills" ? "Collapse" : "Expand"}</span>
        </button>

        {activeTab === "skills" && (
          <div className="p-4 border-t border-gray-100 dark:border-gray-800 space-y-4">
            
            {/* Add a manual skill */}
            <form onSubmit={handleAddSkill} className="flex gap-2">
              <input
                type="text"
                placeholder="Type a skill (e.g. TypeScript) and hit enter..."
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                className="flex-grow px-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
              <button
                type="submit"
                className="px-3 py-1.5 text-xs bg-gray-150 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 font-bold rounded-lg transition-colors border border-gray-200 dark:border-gray-700 cursor-pointer text-gray-700 dark:text-gray-300"
              >
                Add tag
              </button>
            </form>

            {/* List of current skills */}
            <div className="flex flex-wrap gap-1.5 p-3 rounded-lg border border-gray-100 dark:border-gray-800 bg-gray-55/40 dark:bg-gray-950/20">
              {skills.length === 0 ? (
                <span className="text-[11px] text-gray-400 font-medium">No skill tags listed. Add tags manually or request AI suggestions.</span>
              ) : (
                skills.map((skill, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 font-medium border border-gray-200 dark:border-gray-700"
                  >
                    <span>{skill}</span>
                    <button
                      type="button"
                      onClick={() => deleteSkill(skill)}
                      className="text-gray-400 hover:text-red-500 transition-colors cursor-pointer"
                    >
                      <X size={10} />
                    </button>
                  </span>
                ))
              )}
            </div>

            {/* AI Generator Box */}
            <div className="p-3.5 rounded-xl border border-dashed border-indigo-150 bg-indigo-50/10 dark:bg-indigo-950/5 space-y-3">
              <div className="flex items-center gap-2 text-indigo-700 dark:text-indigo-300">
                <Sparkles size={16} />
                <h4 className="text-xs font-bold uppercase tracking-wide">AI Skills Blueprint Generator</h4>
              </div>

              <div className="text-[11px] text-gray-500 dark:text-gray-400">
                Generate high-relevance professional and soft skill suggestions mapped to your target job title.
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  placeholder="Focus details (e.g. Cloud Architecture, DevOps)"
                  value={aiSkillFocus}
                  onChange={(e) => setAiSkillFocus(e.target.value)}
                  className="flex-grow px-2.5 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <button
                  type="button"
                  onClick={handleAiSkillSuggest}
                  disabled={loading.skills}
                  className="flex items-center justify-center gap-1 py-1.5 px-3 rounded-lg text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 dark:disabled:bg-gray-800 cursor-pointer shadow-sm transition-colors shrink-0"
                >
                  <Sparkles size={11} className={loading.skills ? "animate-spin" : ""} />
                  <span>{loading.skills ? "Analyzing..." : "Suggest AI Skills"}</span>
                </button>
              </div>
            </div>

          </div>
        )}
      </div>

      {/* Accordion Tab 5: Projects */}
      <div className="border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden bg-white dark:bg-gray-900">
        <button
          onClick={() => setActiveTab(activeTab === "projects" ? "" : "projects")}
          className="w-full flex items-center justify-between p-4 font-semibold text-left text-gray-800 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all"
        >
          <div className="flex items-center gap-3">
            <FolderGit size={18} className="text-indigo-500" />
            <span>Featured Projects ({projects.length})</span>
          </div>
          <span className="text-gray-400 font-normal">{activeTab === "projects" ? "Collapse" : "Expand"}</span>
        </button>

        {activeTab === "projects" && (
          <div className="p-4 border-t border-gray-100 dark:border-gray-800 space-y-4">
            {projects.length === 0 ? (
              <div className="text-center py-6 text-xs text-gray-400 dark:text-gray-500 font-medium">
                No projects listed. Click below to add an entry.
              </div>
            ) : (
              <div className="space-y-4 divide-y divide-gray-100 dark:divide-gray-800">
                {projects.map((proj, index) => (
                  <div key={proj.id} className={index > 0 ? "pt-4 space-y-3" : "space-y-3"}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Project Entry #{index + 1}</span>
                      <button
                        type="button"
                        onClick={() => deleteProject(proj.id)}
                        className="flex items-center gap-1 px-2 py-1 rounded bg-red-50 hover:bg-red-100 text-red-600 dark:bg-red-950/20 dark:hover:bg-red-950/40 text-[10.5px] font-semibold transition-colors shadow-sm"
                      >
                        <Trash2 size={11} /> Remove
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5 font-medium">Project Name</label>
                        <input
                          type="text"
                          value={proj.title}
                          onChange={(e) => handleProjectChange(proj.id, "title", e.target.value)}
                          placeholder="e.g. Self-Healing App Analytics"
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5 font-medium">Technologies Used</label>
                        <input
                          type="text"
                          value={proj.technologies}
                          onChange={(e) => handleProjectChange(proj.id, "technologies", e.target.value)}
                          placeholder="e.g. React, Node.js, Tailwind CSS"
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5 font-medium">Project Website / Repository URL</label>
                        <input
                          type="text"
                          value={proj.url}
                          onChange={(e) => handleProjectChange(proj.id, "url", e.target.value)}
                          placeholder="e.g. https://github.com/example/analytics"
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Project description list with AI assistant button */}
                      <div className="sm:col-span-2 border-t border-gray-50 dark:border-gray-800 pt-3">
                        <div className="flex items-center justify-between mb-1.5">
                          <label className="block text-[10.5px] font-semibold text-gray-600 dark:text-gray-400 mb-0.5 font-medium">
                            Project Description & Highlights
                          </label>
                          <button
                            type="button"
                            onClick={() => handleAiProjectBullets(proj.id, proj.title, proj.technologies, proj.description)}
                            disabled={loading.project}
                            className="flex items-center gap-1 text-[10px] font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 dark:disabled:bg-gray-800 px-2 py-0.5 rounded cursor-pointer transition-colors shadow-sm"
                          >
                            <Sparkles size={10} className={loading.project ? "animate-spin" : ""} />
                            <span>{loading.project ? "AI Auto-Bulleting..." : "AI Generate Achievement Bullets"}</span>
                          </button>
                        </div>
                        <textarea
                          rows={3}
                          value={proj.description}
                          onChange={(e) => handleProjectChange(proj.id, "description", e.target.value)}
                          placeholder="State what you accomplished. Tip: Start your points with bullet dots '• ' or '- ' for supreme ATS-friendly visualization."
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-sans"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={addProject}
              className="w-full flex items-center justify-center gap-1.5 py-2 border-2 border-dashed border-gray-200 dark:border-gray-800 hover:border-indigo-400 dark:hover:border-indigo-800 rounded-lg text-indigo-600 text-xs font-semibold hover:bg-indigo-50/50 dark:hover:bg-indigo-950/10 cursor-pointer transition-all"
            >
              <Plus size={14} /> Add Project Entry
            </button>
          </div>
        )}
      </div>

      {/* Accordion Tab 6: Certifications, Languages, and References */}
      <div className="border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden bg-white dark:bg-gray-900">
        <button
          onClick={() => setActiveTab(activeTab === "extra" ? "" : "extra")}
          className="w-full flex items-center justify-between p-4 font-semibold text-left text-gray-800 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all"
        >
          <div className="flex items-center gap-3">
            <Award size={18} className="text-amber-500" />
            <span>Certifications, Languages & References</span>
          </div>
          <span className="text-gray-400 font-normal">{activeTab === "extra" ? "Collapse" : "Expand"}</span>
        </button>

        {activeTab === "extra" && (
          <div className="p-4 border-t border-gray-100 dark:border-gray-800 space-y-6">
            
            {/* Certifications Block */}
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-gray-150 dark:border-gray-800 pb-1">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1">
                  <Award size={14} className="text-indigo-500" /> Certifications ({certifications.length})
                </h4>
                <button
                  type="button"
                  onClick={addCert}
                  className="flex items-center gap-1 text-[10.5px] text-indigo-600 font-bold hover:underline cursor-pointer"
                >
                  <Plus size={12} /> Add Cert
                </button>
              </div>

              {certifications.length === 0 ? (
                <p className="text-[11px] text-gray-400 italic">No certifications listed.</p>
              ) : (
                <div className="space-y-3">
                  {certifications.map((cert) => (
                    <div key={cert.id} className="flex gap-2 items-end">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 flex-grow">
                        <div>
                          <input
                            type="text"
                            placeholder="Name (e.g. AWS Certified)"
                            value={cert.name}
                            onChange={(e) => handleCertChange(cert.id, "name", e.target.value)}
                            className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-1"
                          />
                        </div>
                        <div>
                          <input
                            type="text"
                            placeholder="Issuer (e.g. Amazon)"
                            value={cert.issuer}
                            onChange={(e) => handleCertChange(cert.id, "issuer", e.target.value)}
                            className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 focus:outline-none"
                          />
                        </div>
                        <div>
                          <input
                            type="month"
                            value={cert.date}
                            onChange={(e) => handleCertChange(cert.id, "date", e.target.value)}
                            className="w-full px-2 py-0.5 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100"
                          />
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => deleteCert(cert.id)}
                        className="p-1 rounded bg-red-55 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/40 text-red-600 cursor-pointer transition-all"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Languages Block */}
            <div className="space-y-3 pt-4 border-t border-gray-100 dark:border-gray-800">
              <div className="flex items-center justify-between border-b border-gray-150 dark:border-gray-800 pb-1">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1">
                  <Globe size={14} className="text-indigo-500" /> Languages ({languages.length})
                </h4>
                <button
                  type="button"
                  onClick={addLanguage}
                  className="flex items-center gap-1 text-[10.5px] text-indigo-600 font-bold hover:underline"
                >
                  <Plus size={12} /> Add Language
                </button>
              </div>

              {languages.length === 0 ? (
                <p className="text-[11px] text-gray-400 italic">No languages listed.</p>
              ) : (
                <div className="space-y-3">
                  {languages.map((lang) => (
                    <div key={lang.id} className="flex gap-2 items-center">
                      <div className="grid grid-cols-2 gap-2 flex-grow">
                        <input
                          type="text"
                          placeholder="Language (e.g. English)"
                          value={lang.name}
                          onChange={(e) => handleLanguageChange(lang.id, "name", e.target.value)}
                          className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100"
                        />
                        <select
                          value={lang.proficiency}
                          onChange={(e) => handleLanguageChange(lang.id, "proficiency", e.target.value)}
                          className="px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100"
                        >
                          <option value="Native">Native</option>
                          <option value="Fluent">Fluent</option>
                          <option value="Professional">Professional</option>
                          <option value="Conversational">Conversational</option>
                          <option value="Basic">Basic</option>
                        </select>
                      </div>
                      <button
                        type="button"
                        onClick={() => deleteLanguage(lang.id)}
                        className="p-1 rounded bg-red-55 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/40 text-red-600 cursor-pointer"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* References Block */}
            <div className="space-y-3 pt-4 border-t border-gray-100 dark:border-gray-800">
              <div className="flex items-center justify-between border-b border-gray-150 dark:border-gray-800 pb-1">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1">
                  <HeartHandshake size={14} className="text-indigo-500" /> References ({references.length})
                </h4>
                <button
                  type="button"
                  onClick={addReference}
                  className="flex items-center gap-1 text-[10.5px] text-indigo-600 font-bold hover:underline"
                >
                  <Plus size={12} /> Add Reference
                </button>
              </div>

              {references.length === 0 ? (
                <p className="text-[11px] text-gray-400 italic">No reference accounts listed.</p>
              ) : (
                <div className="space-y-3">
                  {references.map((ref) => (
                    <div key={ref.id} className="p-3 border border-gray-100 dark:border-gray-800 rounded-lg space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-bold text-gray-400 uppercase">Ref contact</span>
                        <button
                          type="button"
                          onClick={() => deleteReference(ref.id)}
                          className="text-red-500 hover:text-red-600 text-xs flex items-center gap-0.5"
                        >
                          <Trash2 size={11} /> Remove
                        </button>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="text"
                          placeholder="Reference name"
                          value={ref.name}
                          onChange={(e) => handleReferenceChange(ref.id, "name", e.target.value)}
                          className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800"
                        />
                        <input
                          type="text"
                          placeholder="Title / VP, company"
                          value={ref.company}
                          onChange={(e) => handleReferenceChange(ref.id, "company", e.target.value)}
                          className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800"
                        />
                        <input
                          type="text"
                          placeholder="Relation (e.g. Manager)"
                          value={ref.relation}
                          onChange={(e) => handleReferenceChange(ref.id, "relation", e.target.value)}
                          className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800"
                        />
                        <input
                          type="text"
                          placeholder="Contact Info (Email/Phone)"
                          value={ref.contact}
                          onChange={(e) => handleReferenceChange(ref.id, "contact", e.target.value)}
                          className="w-full px-2 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-800"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}
      </div>

    </div>
  );
}
