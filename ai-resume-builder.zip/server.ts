import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "15mb" }));

  // Initialize Gemini Client
  let ai: GoogleGenAI | null = null;
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini AI Client initialized successfully.");
  } else {
    console.warn("GEMINI_API_KEY environment variable is not defined.");
  }

  // API endpoint for AI generation
  app.post("/api/ai/generate", async (req, res) => {
    try {
      if (!ai) {
        return res.status(500).json({
          error: "Gemini API key is not configured. Please supply GEMINI_API_KEY in the Secrets panel."
        });
      }

      const { type, payload } = req.body;
      if (!type || !payload) {
        return res.status(400).json({ error: "Missing type or payload" });
      }

      let prompt = "";

      if (type === "summary") {
        prompt = `Generate a highly professional, compelling resume executive summary (about 3 sentences, around 50-70 words).
Target Job Title/Role: ${payload.title || "Professional"}
Key Areas of Expertise: ${payload.skills || "Not specified"}
Experience Highlights & Profile: ${payload.experience || "Not specified"}
Tone: Direct, professional, ATS-optimized, high impact. 
Strict requirement: Output the summary paragraph directly. NO introductory text, NO surrounding quotation marks, NO commentary.`;
      } else if (type === "skills") {
        prompt = `Suggest 8 key technical or professional skills list for a resume.
Target Job Title/Role: ${payload.title || "Professional"}
Existing Skills context: ${payload.skills || ""}
Focus details: ${payload.focus || ""}
Strict requirement: Output the format as a flat valid JSON array of strings ONLY. Example: ["React", "TypeScript", "Node.js", "Docker"]. Do not output markdown backticks, markdown code blocks, or explanations.`;
      } else if (type === "project") {
        prompt = `Generate exactly 3 professional resume achievement bullet points for a project entry.
Project Name: ${payload.projectTitle || "Personal Project"}
Technologies Used: ${payload.technologies || "Modern Tech Stack"}
Scope Description/Goals: ${payload.description || "Developed an application."}
Strict requirement: Output 3 plain text bullet points starting with "- " or "• ". NO introductory text, NO title, NO bold markdown headers. Focus on action-oriented results with clear descriptive impact.`;
      } else {
        return res.status(400).json({ error: "Unsupported generation type" });
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
      });

      let text = response.text || "";
      // Strip out markdown code blocks if the model wrapped it anyway (e.g. ```json ... ```)
      if (type === "skills") {
        text = text.trim();
        if (text.startsWith("```")) {
          text = text.replace(/^```(json)?/, "").replace(/```$/, "").trim();
        }
      }

      res.json({ text: text });
    } catch (error: any) {
      console.error("AI generating error:", error);
      res.status(500).json({ error: error.message || "Failed to generate AI writing assistance." });
    }
  });

  // Serve static files in development & production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://localhost:${PORT}`);
  });
}

startServer();
